﻿using ProiectPSSC.Models;
using ProiectPSSC.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace ProiectPSSC_Tests
{
    public class BookRepositoryTests
	{
		[Fact]
		public void GetAllBooks()
		{
			// Arrange
			var repo = new BookRepository();

			// Act
			var result = repo.GetAllBooks();

			// Assert
			Assert.Equal(3, result.Count);
		}

		[Fact]
		public void CreateBook()
		{
			// Arrange
			var repo = new BookRepository();

			var book = new Book(Guid.NewGuid(), "Viata dupa Auschwitz", "Eva Schloss", "Rao Books", 288, "Romanian");

			// Act
			repo.AddNewBook(book);
			var result = repo.GetAllBooks();

			// Assert
			Assert.Equal(4, result.Count);
		}
	}
}

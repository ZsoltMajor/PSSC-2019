﻿using MassTransit;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ProiectPSSC.Controllers;
using ProiectPSSC.Models;
using ProiectPSSC.Repositories;
using ProiectPSSC.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit;

namespace ProiectPSSC_Tests
{
	public class BookControllerTests
    {
		[Fact]
		public void ReturnIndex()
		{
			// Arrange
			var bus = new Mock<IBusControl>();
			var repo = new Mock<IBookRepository>();

			repo.Setup(repo => repo.GetAllBooks())
				.Returns(BookTestData.Books);

			var bookService = new BookService(bus.Object, repo.Object);

			var controller = new BookController(bookService);

			// Act
			var result = controller.Index();

			// Assert
			var viewResult = Assert.IsType<ViewResult>(result);
			var model = Assert.IsAssignableFrom<List<Book>>(viewResult.ViewData.Model);

			Assert.Equal(2, model.Count());

			Assert.Equal("J. K. Rowling", model[0].author);
			Assert.Equal("Harry Potter", model[0].title);
			Assert.Equal("J.R.R. Tolkien", model[1].author);
			Assert.Equal("The Fellowship of the Ring", model[1].title);

		}
	}
}

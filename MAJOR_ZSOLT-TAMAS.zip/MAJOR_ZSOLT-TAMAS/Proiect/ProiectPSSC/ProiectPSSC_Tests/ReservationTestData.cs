﻿using ProiectPSSC.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProiectPSSC_Tests
{
	public class ReservationTestData
	{
		public static List<Reservation> Reservations = new List<Reservation>()
		{
			new Reservation(Guid.NewGuid(), DateTime.Now, "Harry Potter", "Dan"),

			new Reservation(Guid.NewGuid(), DateTime.Now, "The Fellowship of the Ring", "Emil")
		};

		public static List<Book> Books = new List<Book>()
		{
			new Book(Guid.NewGuid(), "Harry Potter", "J. K. Rowling", "Bloomsbury", 621, "English"),

            new Book(Guid.NewGuid(), "The Fellowship of the Ring", "J.R.R. Tolkien", "Mariner Books", 432, "English")
		};

	}
}

﻿using ProiectPSSC.Models;
using ProiectPSSC.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace ProiectPSSC_Tests
{
	public class ReservationRepositoryTests
	{
		[Fact]
		public void GetAllReservations()
		{
			// Arrange
			var repo = new ReservationRepository();

			// Act
			var result = repo.GetAllReservations();

			// Assert
			Assert.Equal(3, result.Count);
		}

		[Fact]
		public void CreateReservation()
		{
			// Arrange
			var repo = new ReservationRepository();

			var reservation = new Reservation(Guid.NewGuid(), DateTime.Now, "Test", "Ion");

			// Act
			repo.CreateReservation(reservation);
			var result = repo.GetAllReservations();

			// Assert
			Assert.Equal(4, result.Count);
		}
	}
}

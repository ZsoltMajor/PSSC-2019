﻿using ProiectPSSC.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProiectPSSC_Tests
{
    class BookTestData
    {
        public static List<Book> Books = new List<Book>()
        {
            new Book(Guid.NewGuid(), "Harry Potter", "J. K. Rowling", "Bloomsbury", 621, "English"),

            new Book(Guid.NewGuid(), "The Fellowship of the Ring", "J.R.R. Tolkien", "Mariner Books", 432, "English")
        };
    }
}

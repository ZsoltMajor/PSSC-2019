using MassTransit;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ProiectPSSC.Controllers;
using ProiectPSSC.Models;
using ProiectPSSC.Repositories;
using ProiectPSSC.Services;
using ProiectPSSC_Tests;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace ProiectPSSC_Tests
{
	public class ReservationControllerTests
	{
		[Fact]
		public void ReturnIndex()
		{
			// Arrange
			var bus = new Mock<IBusControl>();
			var repo = new Mock<IReservationRepository>();

			repo.Setup(repo => repo.GetAllReservations())
				.Returns(ReservationTestData.Reservations);

			var bookrepo = new Mock<IBookRepository>();

			bookrepo.Setup(repo => repo.GetAllBooks())
				.Returns(ReservationTestData.Books);

			var reservationService = new ReservationService(bus.Object, repo.Object);
			var bookService = new BookService(bus.Object, bookrepo.Object);

			var controller = new ReservationController(reservationService, bookService);

			// Act
			var result = controller.Index();

			// Assert
			var viewResult = Assert.IsType<ViewResult>(result);
			var model = Assert.IsAssignableFrom<List<Reservation>>(viewResult.ViewData.Model);

			Assert.Equal(2, model.Count());

			Assert.Equal("Dan", model[0].name);
			Assert.Equal("Harry Potter", model[0].reservedBook);
			Assert.Equal("Emil", model[1].name);
			Assert.Equal("The Fellowship of the Ring", model[1].reservedBook);

		}
	}
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProiectPSSC.Services;
using ProiectPSSC.Models;
using Microsoft.AspNetCore.Http;

namespace ProiectPSSC.Controllers
{
	public class ReservationController : Controller
	{
		private readonly IReservationService reservationService;
		private readonly IBookService bookService;

		public ReservationController(IReservationService reservationService, IBookService bookService)
		{
			this.reservationService = reservationService;
			this.bookService = bookService;
		}

		// GET: Reservation
		public ActionResult Index()
		{
			return View(reservationService.GetAllReservations());
		}

		// GET: Reservation/Details/5
		public ActionResult Details(int id)
		{
			return View();
		}

		// GET: Reservation/Create
		public ActionResult Create()
		{
			ViewData["Books"] = bookService.GetAllBooks();
			return View();
		}

		// POST: Reservation/Create
		[HttpPost]
		[ValidateAntiForgeryToken]
		public ActionResult Create(IncompleteReservation reservation)
		{
			try
			{
				Reservation reservationtoBeAdded = new Reservation(Guid.NewGuid(), reservation.date, reservation.reservedBook, reservation.name);
				reservationService.CreateReservation(reservationtoBeAdded);

				return RedirectToAction(nameof(Index));
			}
			catch
			{
				ViewData["Books"] = bookService.GetAllBooks();
				return View();
			}
		}

		// GET: Reservation/Edit/5
		public ActionResult Edit(int id)
		{
			return View();
		}

		// POST: Reservation/Edit/5
		[HttpPost]
		[ValidateAntiForgeryToken]
		public ActionResult Edit(int id, IFormCollection collection)
		{
			try
			{
				// TODO: Add update logic here

				return RedirectToAction(nameof(Index));
			}
			catch
			{
				return View();
			}
		}

		// GET: Reservation/Delete/5
		public ActionResult Delete(Guid id)
		{
			var reservation = reservationService.GetReservationById(id);
			return View(reservation);
		}

		// POST: Reservation/Delete/5
		[HttpPost]
		[ValidateAntiForgeryToken]
		public ActionResult Delete(Guid id, IFormCollection collection)
		{
			try
			{
				reservationService.DeleteReservation(id);

				return RedirectToAction(nameof(Index));
			}
			catch
			{
				return View();
			}
		}
	}
}
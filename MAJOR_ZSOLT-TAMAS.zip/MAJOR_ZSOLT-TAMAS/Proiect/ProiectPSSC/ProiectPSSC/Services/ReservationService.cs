﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MassTransit;
using ProiectPSSC.Models;
using ProiectPSSC.Repositories;
using ConsoleApplication;

namespace ProiectPSSC.Services
{
	public interface IReservationService
	{
		void CreateReservation(Reservation reservation);
		List<Reservation> GetAllReservations();
		Reservation GetReservationById(Guid id);
		void DeleteReservation(Guid id);
	}

	public class ReservationService : IReservationService
	{
		private readonly IBusControl bus;
		private readonly IReservationRepository repository;

		public ReservationService(IBusControl bus, IReservationRepository repository)
		{
			this.bus = bus;
			this.repository = repository;
		}

		public void CreateReservation(Reservation reservation)
		{
			repository.CreateReservation(reservation);

			bus.Publish(new ReservationAdded()
			{
				id = reservation.id,
				date = reservation.date,
				user = reservation.name,
				title = reservation.reservedBook
			});
		}
		
		public void DeleteReservation(Guid id)
		{
			var reservation = repository.GetReservationById(id);
			repository.DeleteReservation(reservation);

			bus.Publish(new ReservationDeleted()
			{
				id = reservation.id,
				date = reservation.date,
				user = reservation.name,
				title = reservation.reservedBook
			});
		}

		public List<Reservation> GetAllReservations()
		{
			return repository.GetAllReservations();
		}

		public Reservation GetReservationById(Guid id)
		{
			return repository.GetReservationById(id);
		}
	}
}

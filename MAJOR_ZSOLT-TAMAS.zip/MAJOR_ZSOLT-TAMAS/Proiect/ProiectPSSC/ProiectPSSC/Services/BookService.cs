﻿using System;
using System.Collections.Generic;
using ProiectPSSC.Models;
using MassTransit;
using ProiectPSSC.Repositories;
using ConsoleApplication;

namespace ProiectPSSC.Services
{
    public interface IBookService
    {
        void AddNewBook(Book book);
        List<Book> GetAllBooks();
        Book GetBookById(Guid id);
        void DeleteBook(Guid id);
    }

    public class BookService : IBookService
    {
        private readonly IBusControl bus;
        private readonly IBookRepository repository;

        public BookService(IBusControl bus, IBookRepository repository)
        {
            this.bus = bus;
            this.repository = repository;
        }

        public void AddNewBook(Book book)
        {
            repository.AddNewBook(book);

            bus.Publish(new BookAdded()
            {
                id = book.id,
                title = book.title,
                author = book.author,
                publisher = book.publisher,
                language = book.language,
                nrOfPages = book.nrOfPages
            });
        }

        public void DeleteBook(Guid id)
        {
            var book = repository.GetBookById(id);
            repository.DeleteBook(book);

            bus.Publish(new BookDeleted()
            {
                id = book.id,
                title = book.title,
                author = book.author,
                publisher = book.publisher,
                language = book.language,
                nrOfPages = book.nrOfPages
            });
        }

        public List<Book> GetAllBooks()
        {
            return repository.GetAllBooks();
        }

        public Book GetBookById(Guid id)
        {
            return repository.GetBookById(id);
        }
    }
}


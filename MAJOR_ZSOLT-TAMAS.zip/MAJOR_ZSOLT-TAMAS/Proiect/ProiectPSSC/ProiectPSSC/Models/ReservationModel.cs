﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProiectPSSC.Models
{
    public class Reservation
    {
		public Guid id { get; }

		[DataType(DataType.Date)]
		public DateTime date { get; }

		public string reservedBook { get; }

		[Required]
		public string name { get; }

		public Reservation(Guid id, DateTime date, string book, string name)
		{
			this.id = id;
			this.date = date;
			this.reservedBook = book;
			this.name = name;
		}
	}

	public class IncompleteReservation
	{
		public Guid id { get; set; }

		[DataType(DataType.Date)]
		public DateTime date { get; set; }

		public string reservedBook { get; set; }

		[Required]
		public string name { get; set; }
	}
}

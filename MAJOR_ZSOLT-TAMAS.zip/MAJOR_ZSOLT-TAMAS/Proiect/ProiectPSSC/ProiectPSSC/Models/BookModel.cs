﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProiectPSSC.Models
{
    public class Book
    {

        public Guid id { get; }

        [Required]
        public string title { get; }

        [Required]
        public string author { get; }
        public string publisher { get; }
        public int nrOfPages { get; }
        public string language { get; }

        public Book(Guid id, string title, string author, string publisher, int nrOfPages, string language)
        {
            this.id = id;
            this.title = title;
            this.author = author;
            this.publisher = publisher;
            this.nrOfPages = nrOfPages;
            this.language = language;
        }
    }
    public class IncompleteBook
    {

        public Guid id { get; set; }

        [Required]
        public string title { get; set; }

        [Required]
        public string author { get; set; }
        public string publisher { get; set; }
        public int nrOfPages { get; set; }
        public string language { get; set; }
    }
}

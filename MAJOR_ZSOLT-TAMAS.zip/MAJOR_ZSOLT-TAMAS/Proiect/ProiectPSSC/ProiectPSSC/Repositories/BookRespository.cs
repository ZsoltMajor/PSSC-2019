﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProiectPSSC.Models;

namespace ProiectPSSC.Repositories
{
    public interface IBookRepository
    {
        void AddNewBook(Book book);
        List<Book> GetAllBooks();
        Book GetBookById(Guid id);
        void DeleteBook(Book book);
    }
    public class BookRepository : IBookRepository
    {
        private readonly List<Book> bookList;

        public BookRepository()
        {
            bookList = new List<Book>();
            Book book = new Book(Guid.NewGuid(), "Harry Potter", "J. K. Rowling", "Bloomsbury", 621, "English");
            bookList.Add(book);

            book = new Book(Guid.NewGuid(), "The Fellowship of the Ring", "J.R.R. Tolkien", "Mariner Books", 432, "English");
            bookList.Add(book);

            book = new Book(Guid.NewGuid(), "Viata dupa Auschwitz", "Eva Schloss", "Rao Books", 288, "Romanian");
            bookList.Add(book);
        }

        public void AddNewBook(Book book)
        {
            bookList.Add(book);
        }

        public void DeleteBook(Book book)
        {
            bookList.Remove(book);
        }

        public List<Book> GetAllBooks()
        {
            return bookList;
        }

        public Book GetBookById(Guid id)
        {
            return bookList.FirstOrDefault(_ => _.id == id);
        }
    }
}

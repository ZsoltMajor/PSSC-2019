﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProiectPSSC.Models;

namespace ProiectPSSC.Repositories
{
	public interface IReservationRepository
	{
		void CreateReservation(Reservation reservation);
		List<Reservation> GetAllReservations();
		Reservation GetReservationById(Guid id);
		void DeleteReservation(Reservation reservation);
	}

	public class ReservationRepository : IReservationRepository
	{
		private readonly List<Reservation> reservationList;

		public ReservationRepository()
		{
			reservationList = new List<Reservation>();
			Reservation reservation = new Reservation(Guid.NewGuid(), DateTime.Now, "Harry Potter", "Ava");
			reservationList.Add(reservation);

			reservation = new Reservation(Guid.NewGuid(), DateTime.Now, "Harry Potter", "John Doe");
			reservationList.Add(reservation);

			reservation = new Reservation(Guid.NewGuid(), DateTime.Now, "Viata dupa Auschwitz", "David");
			reservationList.Add(reservation);
		}

		public void CreateReservation(Reservation reservation)
		{
			reservationList.Add(reservation);
		}

		public void DeleteReservation(Reservation reservation)
		{
			reservationList.Remove(reservation);
		}

		public List<Reservation> GetAllReservations()
		{
			return reservationList;
		}

		public Reservation GetReservationById(Guid id)
		{
			return reservationList.FirstOrDefault(_ => _.id == id);
		}
	}
}

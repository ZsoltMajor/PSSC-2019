﻿using MassTransit;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication
{
    class ReservationConsumer : IConsumer<ReservationAdded>,
		  IConsumer<ReservationDeleted>
	{
		public async Task Consume(ConsumeContext<ReservationAdded> context)
		{
			var message = $"Reservation created: {context.Message.id} - title: {context.Message.title}, by: {context.Message.user} ({context.Message.date.ToShortDateString()})";
			await Console.Out.WriteLineAsync(message);
		}

		public async Task Consume(ConsumeContext<ReservationDeleted> context)
		{
			var message = $"Reservation deleted: {context.Message.id} - title: {context.Message.title}, by: {context.Message.user}, ({context.Message.date.ToShortDateString()})";
			await Console.Out.WriteLineAsync(message);
		}
	}
}

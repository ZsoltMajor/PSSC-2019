﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication
{
    public class BookAdded
    {
        public Guid id { get; set; }
        public string title { get; set; }
        public string author { get; set; }
        public string publisher { get; set; }
        public string language { get; set; }
        public int nrOfPages { get; set; }
    }
}

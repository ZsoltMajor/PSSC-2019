﻿using MassTransit;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication
{
    class BookConsumer : IConsumer<BookAdded>,
						 IConsumer<BookDeleted>
	{
		public async Task Consume(ConsumeContext<BookAdded> context)
		{
			var message = $"Book created: {context.Message.id}, Title: {context.Message.title}, From {context.Message.author}, Publisher {context.Message.publisher})";
			await Console.Out.WriteLineAsync(message);
		}

		public async Task Consume(ConsumeContext<BookDeleted> context)
		{
			var message = $"Book deleted: {context.Message.id}, Title: {context.Message.title}, From {context.Message.author}, Publisher {context.Message.publisher})";
			await Console.Out.WriteLineAsync(message);
		}
	}
}

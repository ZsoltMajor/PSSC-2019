﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication
{
    public class ReservationDeleted
    {
		public Guid id { get; set; }
		public string user { get; set; }
		public DateTime date { get; set; }
		public string title { get; set; }
	}
}
